﻿using System;
using System.Windows.Forms;

namespace Fractals
{
    partial class MainWindow
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainWindow));
            this.LeftPanel = new System.Windows.Forms.Panel();
            this.SaveImageButton = new System.Windows.Forms.Button();
            this.CoeffLabel = new System.Windows.Forms.Label();
            this.DeltaTrackBar = new System.Windows.Forms.TrackBar();
            this.CoeffTrackBar = new System.Windows.Forms.TrackBar();
            this.RightAngleTrackBar = new System.Windows.Forms.TrackBar();
            this.LeftAngleTrackBar = new System.Windows.Forms.TrackBar();
            this.LengthCheckBox = new System.Windows.Forms.CheckBox();
            this.RedrawCheckBox = new System.Windows.Forms.CheckBox();
            this.DeltaLabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.RightAngleLabel = new System.Windows.Forms.Label();
            this.LeftAngleLabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.LogoPicture = new System.Windows.Forms.PictureBox();
            this.ColorBoxEnd = new System.Windows.Forms.ComboBox();
            this.ColorBoxBegin = new System.Windows.Forms.ComboBox();
            this.ColorLabelEnd = new System.Windows.Forms.Label();
            this.ColorLabelBegin = new System.Windows.Forms.Label();
            this.RecursionLabel = new System.Windows.Forms.Label();
            this.LengthLabel = new System.Windows.Forms.Label();
            this.ButtonCantor = new System.Windows.Forms.Button();
            this.ButtonSierpinskiTwo = new System.Windows.Forms.Button();
            this.ButtonSierpinski = new System.Windows.Forms.Button();
            this.ButtonKoch = new System.Windows.Forms.Button();
            this.RecursionTrackBar = new System.Windows.Forms.TrackBar();
            this.LengthTrackBar1 = new System.Windows.Forms.TrackBar();
            this.ButtonPythagorean = new System.Windows.Forms.Button();
            this.ScaleLabel = new System.Windows.Forms.Label();
            this.ScaleTrackBar = new System.Windows.Forms.TrackBar();
            this.InfoTextBox = new System.Windows.Forms.TextBox();
            this.DownPanel = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.YOffsetTrackBar = new System.Windows.Forms.TrackBar();
            this.XOffsetTrackBar = new System.Windows.Forms.TrackBar();
            this.YOffsetLabel = new System.Windows.Forms.Label();
            this.XOffsetLabel = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.CenterPanel = new System.Windows.Forms.Panel();
            this.LeftPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DeltaTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CoeffTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RightAngleTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftAngleTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPicture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RecursionTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LengthTrackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ScaleTrackBar)).BeginInit();
            this.DownPanel.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.YOffsetTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.XOffsetTrackBar)).BeginInit();
            this.SuspendLayout();
            // 
            // LeftPanel
            // 
            this.LeftPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(26)))));
            this.LeftPanel.Controls.Add(this.SaveImageButton);
            this.LeftPanel.Controls.Add(this.CoeffLabel);
            this.LeftPanel.Controls.Add(this.DeltaTrackBar);
            this.LeftPanel.Controls.Add(this.CoeffTrackBar);
            this.LeftPanel.Controls.Add(this.RightAngleTrackBar);
            this.LeftPanel.Controls.Add(this.LeftAngleTrackBar);
            this.LeftPanel.Controls.Add(this.LengthCheckBox);
            this.LeftPanel.Controls.Add(this.RedrawCheckBox);
            this.LeftPanel.Controls.Add(this.DeltaLabel);
            this.LeftPanel.Controls.Add(this.label8);
            this.LeftPanel.Controls.Add(this.RightAngleLabel);
            this.LeftPanel.Controls.Add(this.LeftAngleLabel);
            this.LeftPanel.Controls.Add(this.label5);
            this.LeftPanel.Controls.Add(this.label4);
            this.LeftPanel.Controls.Add(this.LogoPicture);
            this.LeftPanel.Controls.Add(this.ColorBoxEnd);
            this.LeftPanel.Controls.Add(this.ColorBoxBegin);
            this.LeftPanel.Controls.Add(this.ColorLabelEnd);
            this.LeftPanel.Controls.Add(this.ColorLabelBegin);
            this.LeftPanel.Controls.Add(this.RecursionLabel);
            this.LeftPanel.Controls.Add(this.LengthLabel);
            this.LeftPanel.Controls.Add(this.ButtonCantor);
            this.LeftPanel.Controls.Add(this.ButtonSierpinskiTwo);
            this.LeftPanel.Controls.Add(this.ButtonSierpinski);
            this.LeftPanel.Controls.Add(this.ButtonKoch);
            this.LeftPanel.Controls.Add(this.RecursionTrackBar);
            this.LeftPanel.Controls.Add(this.LengthTrackBar1);
            this.LeftPanel.Controls.Add(this.ButtonPythagorean);
            this.LeftPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.LeftPanel.Location = new System.Drawing.Point(0, 0);
            this.LeftPanel.Name = "LeftPanel";
            this.LeftPanel.Size = new System.Drawing.Size(300, 1041);
            this.LeftPanel.TabIndex = 0;
            // 
            // SaveImageButton
            // 
            this.SaveImageButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaveImageButton.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SaveImageButton.ForeColor = System.Drawing.Color.White;
            this.SaveImageButton.Location = new System.Drawing.Point(20, 967);
            this.SaveImageButton.Name = "SaveImageButton";
            this.SaveImageButton.Size = new System.Drawing.Size(249, 48);
            this.SaveImageButton.TabIndex = 0;
            this.SaveImageButton.Text = "Save Image";
            this.SaveImageButton.UseVisualStyleBackColor = true;
            this.SaveImageButton.Click += new System.EventHandler(this.SaveImageButton_Click);
            // 
            // CoeffLabel
            // 
            this.CoeffLabel.AutoSize = true;
            this.CoeffLabel.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CoeffLabel.ForeColor = System.Drawing.Color.White;
            this.CoeffLabel.Location = new System.Drawing.Point(6, 763);
            this.CoeffLabel.Name = "CoeffLabel";
            this.CoeffLabel.Size = new System.Drawing.Size(178, 18);
            this.CoeffLabel.TabIndex = 3;
            this.CoeffLabel.Text = "Коэффициент: 2,00";
            // 
            // DeltaTrackBar
            // 
            this.DeltaTrackBar.LargeChange = 10;
            this.DeltaTrackBar.Location = new System.Drawing.Point(149, 858);
            this.DeltaTrackBar.Maximum = 500;
            this.DeltaTrackBar.Name = "DeltaTrackBar";
            this.DeltaTrackBar.Size = new System.Drawing.Size(135, 45);
            this.DeltaTrackBar.TabIndex = 0;
            this.DeltaTrackBar.TabStop = false;
            this.DeltaTrackBar.TickStyle = System.Windows.Forms.TickStyle.None;
            this.DeltaTrackBar.Value = 20;
            this.DeltaTrackBar.Scroll += new System.EventHandler(this.DeltaTrackBar_Scroll);
            // 
            // CoeffTrackBar
            // 
            this.CoeffTrackBar.LargeChange = 10;
            this.CoeffTrackBar.Location = new System.Drawing.Point(181, 763);
            this.CoeffTrackBar.Maximum = 500;
            this.CoeffTrackBar.Minimum = 125;
            this.CoeffTrackBar.Name = "CoeffTrackBar";
            this.CoeffTrackBar.Size = new System.Drawing.Size(104, 45);
            this.CoeffTrackBar.TabIndex = 6;
            this.CoeffTrackBar.TabStop = false;
            this.CoeffTrackBar.TickStyle = System.Windows.Forms.TickStyle.None;
            this.CoeffTrackBar.Value = 200;
            this.CoeffTrackBar.Scroll += new System.EventHandler(this.CoeffTrackBar_Scroll);
            // 
            // RightAngleTrackBar
            // 
            this.RightAngleTrackBar.Location = new System.Drawing.Point(181, 733);
            this.RightAngleTrackBar.Maximum = 90;
            this.RightAngleTrackBar.Minimum = 30;
            this.RightAngleTrackBar.Name = "RightAngleTrackBar";
            this.RightAngleTrackBar.Size = new System.Drawing.Size(104, 45);
            this.RightAngleTrackBar.TabIndex = 5;
            this.RightAngleTrackBar.TabStop = false;
            this.RightAngleTrackBar.TickStyle = System.Windows.Forms.TickStyle.None;
            this.RightAngleTrackBar.Value = 45;
            this.RightAngleTrackBar.Scroll += new System.EventHandler(this.RightAngleTrackBar_Scroll);
            // 
            // LeftAngleTrackBar
            // 
            this.LeftAngleTrackBar.Location = new System.Drawing.Point(181, 701);
            this.LeftAngleTrackBar.Maximum = 90;
            this.LeftAngleTrackBar.Minimum = 30;
            this.LeftAngleTrackBar.Name = "LeftAngleTrackBar";
            this.LeftAngleTrackBar.Size = new System.Drawing.Size(104, 45);
            this.LeftAngleTrackBar.TabIndex = 0;
            this.LeftAngleTrackBar.TabStop = false;
            this.LeftAngleTrackBar.TickStyle = System.Windows.Forms.TickStyle.None;
            this.LeftAngleTrackBar.Value = 45;
            this.LeftAngleTrackBar.Scroll += new System.EventHandler(this.LeftAngleTrackBar_Scroll);
            // 
            // LengthCheckBox
            // 
            this.LengthCheckBox.AutoSize = true;
            this.LengthCheckBox.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LengthCheckBox.ForeColor = System.Drawing.Color.White;
            this.LengthCheckBox.Location = new System.Drawing.Point(226, 492);
            this.LengthCheckBox.Name = "LengthCheckBox";
            this.LengthCheckBox.Size = new System.Drawing.Size(73, 25);
            this.LengthCheckBox.TabIndex = 5;
            this.LengthCheckBox.TabStop = false;
            this.LengthCheckBox.Text = "Авто";
            this.LengthCheckBox.UseVisualStyleBackColor = true;
            // 
            // RedrawCheckBox
            // 
            this.RedrawCheckBox.AutoSize = true;
            this.RedrawCheckBox.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.RedrawCheckBox.ForeColor = System.Drawing.Color.White;
            this.RedrawCheckBox.Location = new System.Drawing.Point(23, 927);
            this.RedrawCheckBox.Name = "RedrawCheckBox";
            this.RedrawCheckBox.Size = new System.Drawing.Size(249, 25);
            this.RedrawCheckBox.TabIndex = 5;
            this.RedrawCheckBox.TabStop = false;
            this.RedrawCheckBox.Text = "Включить перерисовку";
            this.RedrawCheckBox.UseVisualStyleBackColor = true;
            // 
            // DeltaLabel
            // 
            this.DeltaLabel.AutoSize = true;
            this.DeltaLabel.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DeltaLabel.ForeColor = System.Drawing.Color.White;
            this.DeltaLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DeltaLabel.Location = new System.Drawing.Point(25, 858);
            this.DeltaLabel.Name = "DeltaLabel";
            this.DeltaLabel.Size = new System.Drawing.Size(120, 21);
            this.DeltaLabel.TabIndex = 3;
            this.DeltaLabel.Text = "Дельта: 20";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(14, 823);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(274, 22);
            this.label8.TabIndex = 0;
            this.label8.Text = "Параметры мно-ва Кантора";
            // 
            // RightAngleLabel
            // 
            this.RightAngleLabel.AutoSize = true;
            this.RightAngleLabel.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.RightAngleLabel.ForeColor = System.Drawing.Color.White;
            this.RightAngleLabel.Location = new System.Drawing.Point(9, 733);
            this.RightAngleLabel.Name = "RightAngleLabel";
            this.RightAngleLabel.Size = new System.Drawing.Size(175, 21);
            this.RightAngleLabel.TabIndex = 3;
            this.RightAngleLabel.Text = "Угол вправо: 45";
            // 
            // LeftAngleLabel
            // 
            this.LeftAngleLabel.AutoSize = true;
            this.LeftAngleLabel.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LeftAngleLabel.ForeColor = System.Drawing.Color.White;
            this.LeftAngleLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LeftAngleLabel.Location = new System.Drawing.Point(20, 701);
            this.LeftAngleLabel.Name = "LeftAngleLabel";
            this.LeftAngleLabel.Size = new System.Drawing.Size(164, 21);
            this.LeftAngleLabel.TabIndex = 3;
            this.LeftAngleLabel.Text = "Угол влево: 45";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Courier New", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(80, 166);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 31);
            this.label5.TabIndex = 0;
            this.label5.Text = "ФРАКТАЛЫ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(12, 664);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(285, 22);
            this.label4.TabIndex = 0;
            this.label4.Text = "Параметры дерева Пифагора";
            // 
            // LogoPicture
            // 
            this.LogoPicture.Image = ((System.Drawing.Image)(resources.GetObject("LogoPicture.Image")));
            this.LogoPicture.InitialImage = ((System.Drawing.Image)(resources.GetObject("LogoPicture.InitialImage")));
            this.LogoPicture.Location = new System.Drawing.Point(38, 12);
            this.LogoPicture.Name = "LogoPicture";
            this.LogoPicture.Size = new System.Drawing.Size(218, 142);
            this.LogoPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.LogoPicture.TabIndex = 1;
            this.LogoPicture.TabStop = false;
            // 
            // ColorBoxEnd
            // 
            this.ColorBoxEnd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(26)))));
            this.ColorBoxEnd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ColorBoxEnd.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ColorBoxEnd.ForeColor = System.Drawing.Color.White;
            this.ColorBoxEnd.FormattingEnabled = true;
            this.ColorBoxEnd.Items.AddRange(new object[] {
            "Белый",
            "Синий",
            "Зеленый",
            "Красный",
            "Фиолетовый",
            "Желтый",
            "Оранжевый",
            "Серый",
            "Невидимый"});
            this.ColorBoxEnd.Location = new System.Drawing.Point(157, 594);
            this.ColorBoxEnd.Name = "ColorBoxEnd";
            this.ColorBoxEnd.Size = new System.Drawing.Size(121, 26);
            this.ColorBoxEnd.TabIndex = 4;
            this.ColorBoxEnd.TabStop = false;
            this.ColorBoxEnd.SelectedIndexChanged += new System.EventHandler(this.ColorBoxEnd_SelectedIndexChanged);
            // 
            // ColorBoxBegin
            // 
            this.ColorBoxBegin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(26)))));
            this.ColorBoxBegin.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ColorBoxBegin.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ColorBoxBegin.ForeColor = System.Drawing.Color.White;
            this.ColorBoxBegin.FormattingEnabled = true;
            this.ColorBoxBegin.Items.AddRange(new object[] {
            "Белый",
            "Синий",
            "Зеленый",
            "Красный",
            "Фиолетовый",
            "Желтый",
            "Оранжевый",
            "Серый",
            "Невидимый"});
            this.ColorBoxBegin.Location = new System.Drawing.Point(157, 557);
            this.ColorBoxBegin.Name = "ColorBoxBegin";
            this.ColorBoxBegin.Size = new System.Drawing.Size(121, 26);
            this.ColorBoxBegin.TabIndex = 4;
            this.ColorBoxBegin.TabStop = false;
            this.ColorBoxBegin.SelectedIndexChanged += new System.EventHandler(this.ColorBoxBegin_SelectedIndexChanged);
            // 
            // ColorLabelEnd
            // 
            this.ColorLabelEnd.AutoSize = true;
            this.ColorLabelEnd.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ColorLabelEnd.ForeColor = System.Drawing.Color.White;
            this.ColorLabelEnd.Location = new System.Drawing.Point(12, 594);
            this.ColorLabelEnd.Name = "ColorLabelEnd";
            this.ColorLabelEnd.Size = new System.Drawing.Size(131, 21);
            this.ColorLabelEnd.TabIndex = 3;
            this.ColorLabelEnd.Text = "Цвет конец:";
            // 
            // ColorLabelBegin
            // 
            this.ColorLabelBegin.AutoSize = true;
            this.ColorLabelBegin.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ColorLabelBegin.ForeColor = System.Drawing.Color.White;
            this.ColorLabelBegin.Location = new System.Drawing.Point(12, 560);
            this.ColorLabelBegin.Name = "ColorLabelBegin";
            this.ColorLabelBegin.Size = new System.Drawing.Size(142, 21);
            this.ColorLabelBegin.TabIndex = 3;
            this.ColorLabelBegin.Text = "Цвет начало:";
            // 
            // RecursionLabel
            // 
            this.RecursionLabel.AutoSize = true;
            this.RecursionLabel.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.RecursionLabel.ForeColor = System.Drawing.Color.White;
            this.RecursionLabel.Location = new System.Drawing.Point(12, 525);
            this.RecursionLabel.Name = "RecursionLabel";
            this.RecursionLabel.Size = new System.Drawing.Size(131, 21);
            this.RecursionLabel.TabIndex = 3;
            this.RecursionLabel.Text = "Рекурсия: 7";
            // 
            // LengthLabel
            // 
            this.LengthLabel.AutoSize = true;
            this.LengthLabel.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LengthLabel.ForeColor = System.Drawing.Color.White;
            this.LengthLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LengthLabel.Location = new System.Drawing.Point(12, 493);
            this.LengthLabel.Name = "LengthLabel";
            this.LengthLabel.Size = new System.Drawing.Size(109, 21);
            this.LengthLabel.TabIndex = 3;
            this.LengthLabel.Text = "Длина: 50";
            // 
            // ButtonCantor
            // 
            this.ButtonCantor.FlatAppearance.BorderSize = 0;
            this.ButtonCantor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonCantor.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ButtonCantor.ForeColor = System.Drawing.Color.White;
            this.ButtonCantor.Image = ((System.Drawing.Image)(resources.GetObject("ButtonCantor.Image")));
            this.ButtonCantor.Location = new System.Drawing.Point(0, 416);
            this.ButtonCantor.Name = "ButtonCantor";
            this.ButtonCantor.Size = new System.Drawing.Size(300, 40);
            this.ButtonCantor.TabIndex = 5;
            this.ButtonCantor.Text = "Множество Кантора";
            this.ButtonCantor.UseVisualStyleBackColor = true;
            this.ButtonCantor.Click += new System.EventHandler(this.ButtonCantor_Click);
            // 
            // ButtonSierpinskiTwo
            // 
            this.ButtonSierpinskiTwo.FlatAppearance.BorderSize = 0;
            this.ButtonSierpinskiTwo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonSierpinskiTwo.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ButtonSierpinskiTwo.ForeColor = System.Drawing.Color.White;
            this.ButtonSierpinskiTwo.Image = ((System.Drawing.Image)(resources.GetObject("ButtonSierpinskiTwo.Image")));
            this.ButtonSierpinskiTwo.Location = new System.Drawing.Point(0, 369);
            this.ButtonSierpinskiTwo.Name = "ButtonSierpinskiTwo";
            this.ButtonSierpinskiTwo.Size = new System.Drawing.Size(300, 40);
            this.ButtonSierpinskiTwo.TabIndex = 4;
            this.ButtonSierpinskiTwo.Text = "Треугольник Серпинского";
            this.ButtonSierpinskiTwo.UseVisualStyleBackColor = true;
            this.ButtonSierpinskiTwo.Click += new System.EventHandler(this.ButtonSierpinski2_Click);
            // 
            // ButtonSierpinski
            // 
            this.ButtonSierpinski.FlatAppearance.BorderSize = 0;
            this.ButtonSierpinski.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonSierpinski.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ButtonSierpinski.ForeColor = System.Drawing.Color.White;
            this.ButtonSierpinski.Image = ((System.Drawing.Image)(resources.GetObject("ButtonSierpinski.Image")));
            this.ButtonSierpinski.Location = new System.Drawing.Point(0, 321);
            this.ButtonSierpinski.Name = "ButtonSierpinski";
            this.ButtonSierpinski.Size = new System.Drawing.Size(300, 40);
            this.ButtonSierpinski.TabIndex = 3;
            this.ButtonSierpinski.Text = "Ковер Серпинского";
            this.ButtonSierpinski.UseVisualStyleBackColor = true;
            this.ButtonSierpinski.Click += new System.EventHandler(this.ButtonSierpinski_Click);
            // 
            // ButtonKoch
            // 
            this.ButtonKoch.FlatAppearance.BorderSize = 0;
            this.ButtonKoch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonKoch.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ButtonKoch.ForeColor = System.Drawing.Color.White;
            this.ButtonKoch.Image = ((System.Drawing.Image)(resources.GetObject("ButtonKoch.Image")));
            this.ButtonKoch.Location = new System.Drawing.Point(0, 273);
            this.ButtonKoch.Name = "ButtonKoch";
            this.ButtonKoch.Size = new System.Drawing.Size(300, 40);
            this.ButtonKoch.TabIndex = 2;
            this.ButtonKoch.Text = "Кривая Коха";
            this.ButtonKoch.UseVisualStyleBackColor = true;
            this.ButtonKoch.Click += new System.EventHandler(this.ButtonKoch_Click);
            // 
            // RecursionTrackBar
            // 
            this.RecursionTrackBar.LargeChange = 1;
            this.RecursionTrackBar.Location = new System.Drawing.Point(150, 525);
            this.RecursionTrackBar.Maximum = 20;
            this.RecursionTrackBar.Minimum = 1;
            this.RecursionTrackBar.Name = "RecursionTrackBar";
            this.RecursionTrackBar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.RecursionTrackBar.Size = new System.Drawing.Size(135, 45);
            this.RecursionTrackBar.TabIndex = 0;
            this.RecursionTrackBar.TabStop = false;
            this.RecursionTrackBar.TickStyle = System.Windows.Forms.TickStyle.None;
            this.RecursionTrackBar.Value = 7;
            this.RecursionTrackBar.Scroll += new System.EventHandler(this.RecursionTrackBar_Scroll);
            // 
            // LengthTrackBar1
            // 
            this.LengthTrackBar1.LargeChange = 50;
            this.LengthTrackBar1.Location = new System.Drawing.Point(123, 493);
            this.LengthTrackBar1.Maximum = 2000;
            this.LengthTrackBar1.Minimum = 10;
            this.LengthTrackBar1.Name = "LengthTrackBar1";
            this.LengthTrackBar1.Size = new System.Drawing.Size(101, 45);
            this.LengthTrackBar1.TabIndex = 5;
            this.LengthTrackBar1.TabStop = false;
            this.LengthTrackBar1.TickStyle = System.Windows.Forms.TickStyle.None;
            this.LengthTrackBar1.Value = 50;
            this.LengthTrackBar1.Scroll += new System.EventHandler(this.LengthTrackBar1_Scroll);
            // 
            // ButtonPythagorean
            // 
            this.ButtonPythagorean.FlatAppearance.BorderSize = 0;
            this.ButtonPythagorean.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonPythagorean.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ButtonPythagorean.ForeColor = System.Drawing.Color.White;
            this.ButtonPythagorean.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPythagorean.Image")));
            this.ButtonPythagorean.Location = new System.Drawing.Point(0, 225);
            this.ButtonPythagorean.Name = "ButtonPythagorean";
            this.ButtonPythagorean.Size = new System.Drawing.Size(300, 40);
            this.ButtonPythagorean.TabIndex = 1;
            this.ButtonPythagorean.Text = "Дерево Пифагора";
            this.ButtonPythagorean.UseVisualStyleBackColor = true;
            this.ButtonPythagorean.Click += new System.EventHandler(this.ButtonPythagorean_Click);
            // 
            // ScaleLabel
            // 
            this.ScaleLabel.AutoSize = true;
            this.ScaleLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(26)))));
            this.ScaleLabel.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ScaleLabel.ForeColor = System.Drawing.Color.White;
            this.ScaleLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ScaleLabel.Location = new System.Drawing.Point(6, 12);
            this.ScaleLabel.Name = "ScaleLabel";
            this.ScaleLabel.Size = new System.Drawing.Size(164, 21);
            this.ScaleLabel.TabIndex = 3;
            this.ScaleLabel.Text = "Увеличение: х1";
            // 
            // ScaleTrackBar
            // 
            this.ScaleTrackBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(26)))));
            this.ScaleTrackBar.LargeChange = 1;
            this.ScaleTrackBar.Location = new System.Drawing.Point(187, 12);
            this.ScaleTrackBar.Maximum = 5;
            this.ScaleTrackBar.Minimum = 1;
            this.ScaleTrackBar.Name = "ScaleTrackBar";
            this.ScaleTrackBar.Size = new System.Drawing.Size(129, 45);
            this.ScaleTrackBar.TabIndex = 0;
            this.ScaleTrackBar.TickStyle = System.Windows.Forms.TickStyle.None;
            this.ScaleTrackBar.Value = 1;
            this.ScaleTrackBar.Scroll += new System.EventHandler(this.ScaleTrackBar_Scroll);
            // 
            // InfoTextBox
            // 
            this.InfoTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.InfoTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(26)))));
            this.InfoTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.InfoTextBox.Font = new System.Drawing.Font("Courier New", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.InfoTextBox.ForeColor = System.Drawing.Color.White;
            this.InfoTextBox.Location = new System.Drawing.Point(6, 32);
            this.InfoTextBox.Name = "InfoTextBox";
            this.InfoTextBox.Size = new System.Drawing.Size(1598, 31);
            this.InfoTextBox.TabIndex = 10;
            this.InfoTextBox.TabStop = false;
            this.InfoTextBox.Text = "Введите параметры и выберите фрактал.";
            this.InfoTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // DownPanel
            // 
            this.DownPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(26)))));
            this.DownPanel.Controls.Add(this.panel4);
            this.DownPanel.Controls.Add(this.InfoTextBox);
            this.DownPanel.Controls.Add(this.panel2);
            this.DownPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DownPanel.Location = new System.Drawing.Point(300, 941);
            this.DownPanel.Name = "DownPanel";
            this.DownPanel.Size = new System.Drawing.Size(1604, 100);
            this.DownPanel.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(26)))));
            this.panel4.Controls.Add(this.YOffsetTrackBar);
            this.panel4.Controls.Add(this.XOffsetTrackBar);
            this.panel4.Controls.Add(this.ScaleLabel);
            this.panel4.Controls.Add(this.YOffsetLabel);
            this.panel4.Controls.Add(this.XOffsetLabel);
            this.panel4.Controls.Add(this.ScaleTrackBar);
            this.panel4.Location = new System.Drawing.Point(5, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(373, 100);
            this.panel4.TabIndex = 0;
            // 
            // YOffsetTrackBar
            // 
            this.YOffsetTrackBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(26)))));
            this.YOffsetTrackBar.LargeChange = 20;
            this.YOffsetTrackBar.Location = new System.Drawing.Point(187, 66);
            this.YOffsetTrackBar.Maximum = 999;
            this.YOffsetTrackBar.Minimum = -999;
            this.YOffsetTrackBar.Name = "YOffsetTrackBar";
            this.YOffsetTrackBar.Size = new System.Drawing.Size(129, 45);
            this.YOffsetTrackBar.SmallChange = 5;
            this.YOffsetTrackBar.TabIndex = 5;
            this.YOffsetTrackBar.TickStyle = System.Windows.Forms.TickStyle.None;
            this.YOffsetTrackBar.Scroll += new System.EventHandler(this.YOffsetTrackBar_Scroll);
            // 
            // XOffsetTrackBar
            // 
            this.XOffsetTrackBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(26)))));
            this.XOffsetTrackBar.LargeChange = 20;
            this.XOffsetTrackBar.Location = new System.Drawing.Point(187, 39);
            this.XOffsetTrackBar.Maximum = 999;
            this.XOffsetTrackBar.Minimum = -999;
            this.XOffsetTrackBar.Name = "XOffsetTrackBar";
            this.XOffsetTrackBar.Size = new System.Drawing.Size(129, 45);
            this.XOffsetTrackBar.SmallChange = 5;
            this.XOffsetTrackBar.TabIndex = 4;
            this.XOffsetTrackBar.TickStyle = System.Windows.Forms.TickStyle.None;
            this.XOffsetTrackBar.Scroll += new System.EventHandler(this.XOffsetTrackBar_Scroll);
            // 
            // YOffsetLabel
            // 
            this.YOffsetLabel.AutoSize = true;
            this.YOffsetLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(26)))));
            this.YOffsetLabel.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.YOffsetLabel.ForeColor = System.Drawing.Color.White;
            this.YOffsetLabel.Location = new System.Drawing.Point(6, 66);
            this.YOffsetLabel.Name = "YOffsetLabel";
            this.YOffsetLabel.Size = new System.Drawing.Size(153, 21);
            this.YOffsetLabel.TabIndex = 1;
            this.YOffsetLabel.Text = "Смещение Y: 0";
            // 
            // XOffsetLabel
            // 
            this.XOffsetLabel.AutoSize = true;
            this.XOffsetLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(26)))));
            this.XOffsetLabel.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.XOffsetLabel.ForeColor = System.Drawing.Color.White;
            this.XOffsetLabel.Location = new System.Drawing.Point(6, 39);
            this.XOffsetLabel.Name = "XOffsetLabel";
            this.XOffsetLabel.Size = new System.Drawing.Size(153, 21);
            this.XOffsetLabel.TabIndex = 0;
            this.XOffsetLabel.Text = "Смещение Х: 0";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(5, 100);
            this.panel2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.CausesValidation = false;
            this.label1.Font = new System.Drawing.Font("Courier New", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(75, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "ФРАКТАЛЫ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(300, 936);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1604, 5);
            this.panel1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.CausesValidation = false;
            this.label2.Font = new System.Drawing.Font("Courier New", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(75, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 31);
            this.label2.TabIndex = 0;
            this.label2.Text = "ФРАКТАЛЫ";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(300, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(5, 936);
            this.panel3.TabIndex = 0;
            // 
            // CenterPanel
            // 
            this.CenterPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CenterPanel.AutoScroll = true;
            this.CenterPanel.Location = new System.Drawing.Point(305, 0);
            this.CenterPanel.Name = "CenterPanel";
            this.CenterPanel.Size = new System.Drawing.Size(1599, 938);
            this.CenterPanel.TabIndex = 2;
            // 
            // MainWindow
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(26)))));
            this.ClientSize = new System.Drawing.Size(1904, 1041);
            this.Controls.Add(this.CenterPanel);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.DownPanel);
            this.Controls.Add(this.LeftPanel);
            this.MinimizeBox = false;
            this.Name = "MainWindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Фракталы";
            this.Resize += new System.EventHandler(this.RefreshGraphics);
            this.LeftPanel.ResumeLayout(false);
            this.LeftPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DeltaTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CoeffTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RightAngleTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftAngleTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPicture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RecursionTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LengthTrackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ScaleTrackBar)).EndInit();
            this.DownPanel.ResumeLayout(false);
            this.DownPanel.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.YOffsetTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.XOffsetTrackBar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel LeftPanel;
        private System.Windows.Forms.Button ButtonPythagorean;
        private System.Windows.Forms.Button ButtonKoch;
        private System.Windows.Forms.Button ButtonSierpinski;
        private System.Windows.Forms.Button ButtonSierpinskiTwo;
        private System.Windows.Forms.Button ButtonCantor;
        private System.Windows.Forms.TextBox InfoTextBox;
        private Panel DownPanel;
        private Label label1;
        private Panel panel1;
        private Panel panel2;
        private Label label2;
        private Panel panel3;
        private Panel CenterPanel;
        private Label LengthLabel;
        private Label RecursionLabel;
        private Label ColorLabelEnd;
        private Label ColorLabelBegin;
        private ComboBox ColorBoxBegin;
        private ComboBox ColorBoxEnd;
        private Label label4;
        private Label label5;
        private PictureBox LogoPicture;
        private Label RightAngleLabel;
        private Label LeftAngleLabel;
        private Label CoeffLabel;
        private Label DeltaLabel;
        private Label label8;
        private CheckBox RedrawCheckBox;
        private TrackBar RecursionTrackBar;
        private TrackBar LengthTrackBar1;
        private CheckBox LengthCheckBox;
        private TrackBar LeftAngleTrackBar;
        private TrackBar CoeffTrackBar;
        private TrackBar RightAngleTrackBar;
        private TrackBar DeltaTrackBar;
        private Button SaveImageButton;
        private Label ScaleLabel;
        private TrackBar ScaleTrackBar;
        private Panel panel4;
        private Label YOffsetLabel;
        private Label XOffsetLabel;
        private TrackBar YOffsetTrackBar;
        private TrackBar XOffsetTrackBar;
    }
}

