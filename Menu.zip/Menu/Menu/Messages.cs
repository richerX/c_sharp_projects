﻿using System;

namespace Menu
{
    class Messages
    {
        // Зеленое сообщение.
        public static void Correct(string message) =>
            ShowColorMessage(message, ConsoleColor.Green);

        // Красное сообщение.
        public static void Wrong(string message) =>
            ShowColorMessage(message, ConsoleColor.Red);

        // Желтое сообщение.
        public static void Info(string message) =>
            ShowColorMessage(message, ConsoleColor.Yellow);

        // Темно-фиолетовое сообщение.
        public static void Menu(string message) =>
            ShowColorMessage(message, ConsoleColor.DarkMagenta);

        // Вывод сообщения на экран в определнном цвете.
        private static void ShowColorMessage(string message, ConsoleColor color)
        {
            var defaultColor = Console.ForegroundColor;
            Console.ForegroundColor = color;
            Console.WriteLine(message);
            Console.ForegroundColor = defaultColor;
        }
    }
}
