﻿using System;

namespace Menu
{
    class CursorMenu
    {
        // Ввод переменных класса.
        private int position;
        private string title;
        private string cursor;
        private string skip = "";
        private string[] commands;

        // Кол-во строчек в title.
        private int titleHeight = 2;

        // Конструктор класса.
        public CursorMenu(string title, string cursor, string[] commands)
        {
            this.position = 0;
            this.title = title;
            this.cursor = cursor + " ";
            this.commands = commands;
            for (int i = 0; i < this.cursor.Length + 1; i++)
                skip += " ";
        }

        // Вывод меню на экран.
        public void Show()
        {
            this.position = 0;
            Messages.Info(title + Environment.NewLine);
            for (int i = 0; i < commands.Length; i++)
            {
                if (i == 0)
                    Messages.Menu(cursor + commands[i]);
                else
                    Messages.Menu(skip + commands[i]);
            }
            Console.SetCursorPosition(Console.WindowWidth - 1, Console.WindowHeight - 1);
        }

        // Обновление положения курсора.
        public void UpdateCursor(int newPosition)
        {
            if (newPosition > commands.Length - 1)
                newPosition = 0;
            if (newPosition < 0)
                newPosition = commands.Length - 1;
            Console.SetCursorPosition(0, position + titleHeight);
            Messages.Menu(skip + commands[position] + " ");
            Console.SetCursorPosition(0, newPosition + titleHeight);
            Messages.Menu(cursor + commands[newPosition] + " ");
            Console.SetCursorPosition(Console.WindowWidth - 1, Console.WindowHeight - 1);
            position = newPosition;
        }

        // Выбор команды.
        public int Select()
        {
            while (true)
            {
                var key = Console.ReadKey();
                switch (key.Key)
                {
                    case ConsoleKey.Enter:
                        Console.SetCursorPosition(0, commands.Length + titleHeight + 1);
                        return position;
                    case ConsoleKey.UpArrow:
                        UpdateCursor(position - 1);
                        break;
                    case ConsoleKey.DownArrow:
                        UpdateCursor(position + 1);
                        break;
                }
            }
        }
    }
}
