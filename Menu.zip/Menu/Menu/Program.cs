﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Menu
{
    class Program
    {
        public static void Menu()
        {
            var title = "Выбери команду";
            var cursor = " >>";
            var commands = File.ReadAllLines("Operations.txt", Encoding.UTF8);
            CursorMenu menu = new CursorMenu(title, cursor, commands);
            while (true)
            {
                try
                {
                    menu.Show();
                    switch (menu.Select() + 1)
                    {
                        case 1:
                            Console.WriteLine("Команда 1");
                            break;
                        case 2:
                            Console.WriteLine("Команда 2");
                            break;
                        case 3:
                            Console.WriteLine("Команда 3");
                            break;
                        case 4:
                            Console.WriteLine("Выход");
                            return;
                    }
                }
                catch (Exception exception)
                {
                    Console.WriteLine("Упс, что-то пошло не так (O_o)");
                    Console.WriteLine();
                    Console.WriteLine("КОД ОШИБКИ");
                    Console.WriteLine(exception);
                    Console.WriteLine();
                }
                ContinueMessage();
            }
        }

        public static void ContinueMessage()
        {
            Console.WriteLine();
            Console.Write("Для продолжения нажмите Enter...");
            Console.ReadLine();
            Console.Clear();
        }

        static void Main(string[] args)
        {
            Messages.Info(File.ReadAllText("Title.txt", Encoding.UTF8));
            ContinueMessage();
            Menu();
        }
    }
}
