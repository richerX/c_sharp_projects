﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Slider_App
{
    public partial class SliderAppMainWindow : Form
    {

        public int SliderPanelsWidth = 250;

        public SliderAppMainWindow()
        {
            InitializeComponent();
            // Задание границ окна.
            Size = new Size(1920, 1080);
            MinimumSize = Screen.PrimaryScreen.Bounds.Size / 2;
            MaximumSize = Screen.PrimaryScreen.Bounds.Size;
            // Добавление изображений.
            Logo.Image = Properties.Resources.logo;
            DashboardButton.BackgroundImage = Properties.Resources.dashboard;
            SettingsButton.BackgroundImage = Properties.Resources.settings;
            // Обнуление ширины панелей.
            DashboardPanel.Width = 0;
            SettingsPanel.Width = 0;
        }

        private void DashboardButton_Click(object sender, EventArgs e)
        {
            ButtonSliderClick(DashboardPanel);
        }

        private void SettingsButton_Click(object sender, EventArgs e)
        {
            ButtonSliderClick(SettingsPanel);
        }

        private void ButtonSliderClick(Panel panel)
        {
            if (panel.Width > 0)
                CloseSlider(panel);
            else
            {
                CloseAllSliders();
                OpenSlider(panel);
            }
            Refresh();
        }

        private void OpenSlider(Panel panel)
        {
            while (panel.Width < SliderPanelsWidth)
            {
                panel.Width += 5;
                Thread.Sleep(15);
            }
        }

        private void CloseSlider(Panel panel)
        {
            while (panel.Width > 0)
            {
                panel.Width -= 5;
                Thread.Sleep(15);
            }
        }

        private void CloseAllSliders()
        {
            DashboardPanel.Width = 0;
            SettingsPanel.Width = 0;
        }
    }
}
